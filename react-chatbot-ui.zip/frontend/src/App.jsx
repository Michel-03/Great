
import React from "react";
import ChatBox from "./ChatBox";

function App() {
  return (
    <div>
      <h2 style={{ textAlign: "center", marginTop: 20 }}>RAG Chatbot</h2>
      <ChatBox />
    </div>
  );
}

export default App;
